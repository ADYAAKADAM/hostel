<?php
include 'conndb.php';
$user="SELECT * FROM `users` WHERE `userid` LIKE 'chethan'";
$exists=mysqli_query($conn,$user);
$nor=mysqli_num_rows($exists);
if($nor>0)
{
    echo "there is a row present in db";
}
?>