<?php
if (isset($_POST["submit"])) {
    session_start();
    include 'conndb.php';
    $code = $_SESSION["code"];
    $capacity = $_POST["capacity"];
    $vacancy = $_POST["vacancy"];
    //$sql = "INSERT INTO `hostel` (`name`, `code`, `location`, `capacity`, `vacancy`, `warden`, `phno`, `email`, `type`, `image`) VALUES ('$hostel', '$code', '$location', '$capacity', '$vacancy', '$warden', '$phone', '$email', '$type', '$img')";
    $sqlu="UPDATE `hostel` SET `capacity` = '$capacity', `vacancy` = '$vacancy' WHERE `hostel`.`code` = '$code'";
    $update = mysqli_query($conn, $sqlu);
    if ($update) {
        echo '<div class="alert alert-success my-3" role="alert">
  <h4 class="alert-heading">Success!</h4>
  <p>RECORD UPDATED SUCCESSFULLY.</p>
  <hr>
  <p class="mb-0">Click <a href="./suphome.php">here</a> to go to home page</p>
</div>';
    } 
    else {
        echo '<div class="alert alert-danger my-3" role="alert">
        <h4 class="alert-heading">Error!</h4>
        <p>Can\'t Update the record.</p>
        <hr>
        <p class="mb-0">' . mysqli_error($conn) . '</p>
      </div>';
    }
}
