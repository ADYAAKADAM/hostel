<?php
$conn=mysqli_connect("localhost","root","","hostel");
if(!$conn)
{
    die("database not found");
}
?>