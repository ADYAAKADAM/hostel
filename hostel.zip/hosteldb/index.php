<?php
 header("Location: logintype.html");
 exit();
?>